# interactive cylinder cat

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ma5a/pen/eYaGyry](https://codepen.io/Ma5a/pen/eYaGyry).

I wondered what a cylindrical cat looks like, so I coded one - I achieved the 3D cylinder effect by combining different kinds of rotations. You can rotate the cat by clicking / touching on it face or tail, and roll the cat by dragging. The cylinder cat also walks around the screen.